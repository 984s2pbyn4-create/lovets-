#include <juce_core/juce_core.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include "../Source/Analysis.h"
#include "../Source/PhraseSearch.h"

using namespace juce;

static int fails = 0;
#define CHECK(cond, msg) do { if (! (cond)) { ++fails; std::cout << "FAIL: " << msg << "\n"; } else std::cout << "ok:   " << msg << "\n"; } while (0)

static AudioBuffer<float> makeBeat (double bpm, double sr, int root, bool minor, double seconds)
{
    AudioBuffer<float> b (2, (int) (sr * seconds));
    b.clear();
    const int third = minor ? 3 : 4;
    const double beat = 60.0 / bpm;
    Random rnd (1);
    for (int i = 0; i < b.getNumSamples(); ++i)
    {
        const double t = i / sr;
        const double ph = std::fmod (t, beat);
        float s = 0;
        // kick
        s += (float) (std::exp (-ph * 25.0) * std::sin (2 * MathConstants<double>::pi * (50 + 80 * std::exp (-ph * 30)) * ph)) * 0.8f;
        // hat on off-beats
        const double ph2 = std::fmod (t + beat / 2, beat);
        s += (float) (std::exp (-ph2 * 60.0) * (rnd.nextFloat() * 2 - 1)) * 0.15f;
        // pad: root, third, fifth (+ octave)
        for (int iv : { 0, third, 7, 12 })
        {
            const double f = 220.0 * std::pow (2.0, (root - 9 + iv) / 12.0);
            s += (float) std::sin (2 * MathConstants<double>::pi * f * t) * 0.08f;
        }
        b.setSample (0, i, s);
        b.setSample (1, i, s);
    }
    return b;
}

int main (int argc, char** argv)
{
    if (argc >= 3 && String (argv[1]) == "gen") // gen out.wav bpm root minor
    {
        auto b = makeBeat (String (argv[3]).getDoubleValue(), 44100, String (argv[4]).getIntValue(), String (argv[5]) == "1", 20);
        WavAudioFormat wav;
        File f (File::getCurrentWorkingDirectory().getChildFile (argv[2]));
        f.deleteFile();
        std::unique_ptr<AudioFormatWriter> w (wav.createWriterFor (new FileOutputStream (f), 44100, 2, 24, {}, 0));
        w->writeFromAudioSampleBuffer (b, 0, b.getNumSamples());
        return 0;
    }
    if (argc >= 3 && String (argv[1]) == "analyse")
    {
        AudioFormatManager fm; fm.registerBasicFormats();
        std::unique_ptr<AudioFormatReader> r (fm.createReaderFor (File::getCurrentWorkingDirectory().getChildFile (argv[2])));
        AudioBuffer<float> b ((int) r->numChannels, (int) r->lengthInSamples);
        r->read (&b, 0, b.getNumSamples(), 0, true, true);
        auto a = lv::analyse (b, r->sampleRate);
        std::cout << a.bpm << " BPM " << lv::keyName (a.key, a.minor) << " sr " << r->sampleRate << "\n";
        return 0;
    }
    for (auto [bpm, root, minor] : { std::tuple { 128.0, 9, true }, { 90.0, 0, false }, { 140.0, 2, true }, { 100.0, 7, false } })
    {
        auto b = makeBeat (bpm, 44100, root, minor, 20);
        auto r = lv::analyse (b, 44100);
        std::cout << "  synthetic " << bpm << " " << lv::keyName (root, minor) << " -> " << r.bpm << " " << lv::keyName (r.key, r.minor)
                  << " (" << lv::camelot (r.key, r.minor) << ") conf " << r.keyConfidence << "\n";
        CHECK (std::abs (r.bpm - bpm) < 1.5, "BPM " + String (bpm));
        CHECK (r.key == root && r.minor == minor, "key " + lv::keyName (root, minor));
    }

    auto p = lv::planFit (128, 64, 9, true, 0, false, true, true);
    CHECK (std::abs (p.tempoRatio - 1.0) < 1e-9 && p.semitones == 0, "planFit half-time + relative key");
    p = lv::planFit (90, 100, 9, true, 11, true, true, true);
    CHECK (std::abs (p.tempoRatio - 100.0 / 90.0) < 1e-9 && p.semitones == 2, "planFit Am->Bm +2");
    p = lv::planFit (120, 120, 0, false, 7, false, true, true);
    CHECK (p.semitones == -5, "planFit C->G = -5");

    CHECK (lv::camelot (9, true) == "8A" && lv::camelot (0, false) == "8B", "camelot");

    // json3: автосубтитры (пословно) + ручные
    const String autoJson = String::fromUTF8 (R"({"events":[
        {"tStartMs":1000,"dDurationMs":3000,"segs":[{"utf8":"Ну"},{"utf8":" Привет,","tOffsetMs":400},{"utf8":" мир!","tOffsetMs":900},{"utf8":" что-то","tOffsetMs":1500}]},
        {"tStartMs":3900,"dDurationMs":10,"aAppend":1,"segs":[{"utf8":"\n"}]},
        {"tStartMs":60000,"dDurationMs":2000,"segs":[{"utf8":"ПРИВЕТИК мир"}]}]})");
    auto words = lv::parseJson3 (autoJson);
    CHECK (words.size() == 7, "json3 words = " + String ((int) words.size()));
    auto hits = lv::findPhrase (words, lv::tokenise (String::fromUTF8 ("привет мир")));
    CHECK (hits.size() == 2, "hits = " + String ((int) hits.size()));
    if (! hits.empty())
    {
        CHECK (std::abs (hits[0].start - 1.4) < 0.01 && std::abs (hits[0].end - 2.5) < 0.01, "hit0 timing " + String (hits[0].start) + "-" + String (hits[0].end));
        std::cout << "  context: " << hits[0].context << "\n";
    }
    hits = lv::findPhrase (words, lv::tokenise (String::fromUTF8 ("Что-то")));
    CHECK (hits.size() == 1, "hyphen phrase");
    CHECK (lv::normaliseWord (String::fromUTF8 ("Ёлка!")) == String::fromUTF8 ("елка"), "normalise ё");
    CHECK (std::abs (lv::parseTime ("1:23.5") - 83.5) < 1e-9 && lv::parseTime ("abc") < 0, "parseTime");

    std::cout << (fails == 0 ? "ALL PASSED\n" : "FAILURES: " + std::to_string (fails) + "\n");
    return fails == 0 ? 0 : 1;
}
