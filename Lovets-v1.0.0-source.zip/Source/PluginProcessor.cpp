#include "PluginProcessor.h"
#include "PluginEditor.h"

using namespace juce;

LovetsProcessor::LovetsProcessor()
    : AudioProcessor (BusesProperties().withInput ("Input", AudioChannelSet::stereo(), true)
                                       .withOutput ("Output", AudioChannelSet::stereo(), true))
{
    formats.registerBasicFormats();
    refreshTools();
    setStatus (tools.ready() ? TR ("Готов к работе. " LOVETS_AUTHOR)
                             : TR ("Нужны yt-dlp и ffmpeg — откройте «Настройки» → «Установить инструменты»"), 0);
}

LovetsProcessor::~LovetsProcessor()
{
    cancel();
    pool.removeAllJobs (true, 10000);
}

bool LovetsProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    const auto out = l.getMainOutputChannelSet();
    return (out == AudioChannelSet::stereo() || out == AudioChannelSet::mono())
        && (l.getMainInputChannelSet().isDisabled() || l.getMainInputChannelSet() == out);
}

void LovetsProcessor::processBlock (AudioBuffer<float>& buffer, MidiBuffer&)
{
    ScopedNoDenormals nd;
    for (int c = getTotalNumInputChannels(); c < getTotalNumOutputChannels(); ++c)
        buffer.clear (c, 0, buffer.getNumSamples());

    if (auto* ph = getPlayHead())
        if (auto pos = ph->getPosition())
            if (auto bpm = pos->getBpm())
                hostBpm = *bpm;

    if (! playing) return;
    const SpinLock::ScopedTryLockType tl (audioLock);
    if (! tl.isLocked() || clip.getNumSamples() == 0) return;

    const double step = clipRate / hostRate;
    double p = playPos.load();
    const float g = previewGain.load();
    const int n = clip.getNumSamples(), chans = clip.getNumChannels();
    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        const int i0 = (int) p;
        if (i0 + 1 >= n) { playing = false; p = 0; break; }
        const float fr = (float) (p - i0);
        for (int c = 0; c < buffer.getNumChannels(); ++c)
        {
            const auto* src = clip.getReadPointer (jmin (c, chans - 1));
            buffer.addSample (c, i, g * (src[i0] + fr * (src[i0 + 1] - src[i0])));
        }
        p += step;
    }
    playPos = p;
}

AudioProcessorEditor* LovetsProcessor::createEditor() { return new LovetsEditor (*this); }

void LovetsProcessor::getStateInformation (MemoryBlock& dest)
{
    auto s = settings.createCopy();
    s.setProperty ("clip", getClipFile().getFullPathName(), nullptr);
    if (auto xml = s.createXml()) copyXmlToBinary (*xml, dest);
}

void LovetsProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
    {
        auto s = ValueTree::fromXml (*xml);
        if (s.isValid())
        {
            settings.copyPropertiesFrom (s, nullptr);
            File f (s.getProperty ("clip").toString());
            if (f.existsAsFile()) loadClip (f);
        }
    }
}

File LovetsProcessor::outputDir() const
{
    File d (settings.getProperty ("outputDir", "").toString());
    if (d.getFullPathName().isEmpty())
        d = File::getSpecialLocation (File::userMusicDirectory).getChildFile ("Lovets");
    d.createDirectory();
    return d;
}

// ------------------------------------------------------------------ служебное
void LovetsProcessor::setStatus (const String& t, float p)
{
    const ScopedLock l (lock);
    status.text = t;
    status.progress = p;
}

void LovetsProcessor::refreshTools()
{
    auto t = lv::locateTools();
    const ScopedLock l (lock);
    tools = t;
}

String LovetsProcessor::toolsSummary() const
{
    const ScopedLock l (lock);
    auto line = [] (const char* name, const File& f, bool required)
    {
        return String (f.existsAsFile() ? TR ("✓ ") : (required ? TR ("✗ ") : TR ("– "))) + name + ": "
             + (f.existsAsFile() ? f.getFullPathName() : String (required ? TR ("не найден") : TR ("не найден (желательно)"))) + "\n";
    };
    return line ("yt-dlp", tools.ytdlp, true) + line ("ffmpeg", tools.ffmpeg, true) + line ("deno", tools.deno, false);
}

void LovetsProcessor::runJob (const String& name, std::function<void()> job)
{
    if (busy) { setStatus (TR ("Подождите, идёт: ") + getStatus().text, getStatus().progress); return; }
    busy = true;
    cancelFlag = false;
    runner.resetKill();
    setStatus (name, -1.0f);
    pool.addJob ([this, job]
    {
        job();
        busy = false;
    });
}

void LovetsProcessor::cancel()
{
    cancelFlag = true;
    runner.kill();
}

void LovetsProcessor::installTools()
{
    runJob (TR ("Установка инструментов…"), [this]
    {
        String err;
        const bool ok = lv::installTools ([this] (const String& s, float p) { setStatus (s, p); }, cancelFlag, err);
        refreshTools();
        setStatus (ok ? TR ("Инструменты установлены и готовы") : TR ("Ошибка установки: ") + err, ok ? 1.0f : 0.0f);
    });
}

// ------------------------------------------------------------------ загрузка
File LovetsProcessor::runDownload (const StringArray& extraArgs, const String& url, const String& suffix)
{
    lv::ToolPaths t;
    { const ScopedLock l (lock); t = tools; }
    if (! t.ready()) { setStatus (TR ("Сначала установите yt-dlp и ffmpeg (вкладка «Настройки»)"), 0); return {}; }

    const int sr = settings.getProperty ("sampleRate", 48000);
    const int bits = settings.getProperty ("bitDepth", 24);
    auto args = lv::ytdlpBase (t, getSetting ("cookies", ""));
    args.addArray ({ "-f", "bestaudio/best", "-x", "--audio-format", "wav",
                     "--postprocessor-args", "ExtractAudio:-ar " + String (sr) + " -c:a " + (bits == 16 ? "pcm_s16le" : "pcm_s24le"),
                     "--windows-filenames", "--progress",
                     "--print", "after_move:filepath",
                     "-o", outputDir().getChildFile ("%(title).80B [%(id)s]" + suffix + ".%(ext)s").getFullPathName() });
    args.addArray (extraArgs);
    args.add (url);

    String lastErr;
    File result;
    const int code = runner.run (args, [&] (const String& line)
    {
        if (line.startsWith ("[download]") && line.containsChar ('%'))
        {
            const auto pct = line.fromFirstOccurrenceOf ("]", false, false).trim().upToFirstOccurrenceOf ("%", false, false);
            setStatus (TR ("Скачиваю: ") + line.fromFirstOccurrenceOf ("]", false, false).trim().substring (0, 60), pct.getFloatValue() / 100.0f);
        }
        else if (line.startsWith ("[ExtractAudio]")) setStatus (TR ("Конвертирую в WAV…"), -1.0f);
        else if (line.startsWith ("ERROR")) lastErr = line;
        else if (line.endsWithIgnoreCase (".wav") && File::isAbsolutePath (line.trim())) result = File (line.trim());
    });

    if (runner.wasKilled()) { setStatus (TR ("Остановлено"), 0); return {}; }
    if (code != 0 || ! result.existsAsFile())
    {
        setStatus (TR ("Ошибка загрузки: ") + (lastErr.isNotEmpty() ? lastErr.substring (0, 220) : TR ("код ") + String (code)), 0);
        return {};
    }
    return result;
}

void LovetsProcessor::downloadUrl (const String& url, double a, double b)
{
    if (url.trim().isEmpty()) { setStatus (TR ("Вставьте ссылку на видео YouTube"), 0); return; }
    runJob (TR ("Подготовка загрузки…"), [this, url, a, b]
    {
        StringArray extra;
        String suffix;
        if (a >= 0 || b > 0)
        {
            const double s = jmax (0.0, a);
            const String e = b > s ? String (b, 3) : String ("inf");
            extra.addArray ({ "--download-sections", "*" + String (s, 3) + "-" + e, "--force-keyframes-at-cuts" });
            suffix = " " + lv::formatTime (s).replaceCharacter (':', '.') + (b > s ? "-" + lv::formatTime (b).replaceCharacter (':', '.') : String());
        }
        auto f = runDownload (extra, url.trim(), suffix);
        if (f.existsAsFile()) { setStatus (TR ("Сохранено: ") + f.getFileName(), 1.0f); loadClipNow (f); }
    });
}

void LovetsProcessor::downloadHit (const lv::Hit& h, bool full)
{
    const double before = settings.getProperty ("padBefore", 0.3);
    const double after  = settings.getProperty ("padAfter", 0.5);
    const String url = "https://www.youtube.com/watch?v=" + h.videoId;
    if (full) downloadUrl (url, -1, -1);
    else      downloadUrl (url, jmax (0.0, h.start - before), h.end + after);
}

// ------------------------------------------------------------------ поиск фраз
void LovetsProcessor::searchPhrase (const String& phrase, const String& lang, int maxVideos)
{
    {
        const ScopedLock l (lock);
        if (! busy) hits.clear();
    }
    ++hitsVersion;
    runJob (TR ("Поиск…"), [this, phrase, lang, maxVideos]
    {
        lv::ToolPaths t;
        { const ScopedLock l (lock); t = tools; }
        if (! t.ready()) { setStatus (TR ("Сначала установите yt-dlp и ffmpeg (вкладка «Настройки»)"), 0); return; }
        lv::SearchCallbacks cb;
        cb.status = [this] (const String& s, float p) { setStatus (s, p); };
        cb.hit = [this] (const lv::Hit& h) { { const ScopedLock l (lock); hits.push_back (h); } ++hitsVersion; };
        lv::runPhraseSearch (phrase, lang, maxVideos, t, getSetting ("cookies", ""), runner, cb);
    });
}

// ------------------------------------------------------------------ клип и анализ
void LovetsProcessor::loadClip (const File& f)
{
    runJob (TR ("Загрузка клипа…"), [this, f] { loadClipNow (f); });
}

void LovetsProcessor::loadClipNow (const File& f)
{
    std::unique_ptr<AudioFormatReader> reader (formats.createReaderFor (f));
    if (reader == nullptr) { setStatus (TR ("Не удалось открыть ") + f.getFileName(), 0); return; }

    const auto maxLen = (int64) (reader->sampleRate * 600.0); // до 10 минут в память
    const int len = (int) jmin (reader->lengthInSamples, maxLen);
    AudioBuffer<float> b ((int) jmin (2u, reader->numChannels), len);
    reader->read (&b, 0, len, 0, true, b.getNumChannels() > 1);

    setStatus (TR ("Определяю BPM и тональность…"), -1.0f);
    auto res = lv::analyse (b, reader->sampleRate);

    playing = false;
    {
        const SpinLock::ScopedLockType sl (audioLock);
        clip = std::move (b);
        clipRate = reader->sampleRate;
        clipSamples = clip.getNumSamples();
        playPos = 0;
    }
    {
        const ScopedLock l (lock);
        clipFile = f;
        analysis = res;
        clipLength = (double) reader->lengthInSamples / reader->sampleRate;
    }
    ++clipVersion;
    setStatus (f.getFileName() + TR ("  •  ") + (res.bpm > 0 ? String (res.bpm, 1) + " BPM" : String ("BPM ?"))
               + TR ("  •  ") + lv::keyName (res.key, res.minor) + " (" + lv::camelot (res.key, res.minor) + ")", 1.0f);
}

static String atempoChain (double t)
{
    StringArray parts;
    while (t < 0.5) { parts.add ("atempo=0.5"); t /= 0.5; }
    while (t > 2.0) { parts.add ("atempo=2.0"); t /= 2.0; }
    parts.add ("atempo=" + String (t, 6));
    return parts.joinIntoString (",");
}

void LovetsProcessor::fitClip (double srcBpm, double dstBpm, int srcKey, bool srcMinor, int dstKey, bool dstMinor,
                               bool fitTempo, bool fitKey, int extraSemis)
{
    const File src = getClipFile();
    if (! src.existsAsFile()) { setStatus (TR ("Сначала скачайте или перетащите WAV"), 0); return; }

    runJob (TR ("Подгонка темпа и тональности…"), [=]
    {
        lv::ToolPaths t;
        { const ScopedLock l (lock); t = tools; }
        if (! t.ffmpeg.existsAsFile()) { setStatus (TR ("Нужен ffmpeg (вкладка «Настройки»)"), 0); return; }

        auto plan = lv::planFit (srcBpm, dstBpm, srcKey, srcMinor, dstKey, dstMinor, fitTempo, fitKey);
        plan.semitones += extraSemis;
        if (std::abs (plan.tempoRatio - 1.0) < 1e-4 && plan.semitones == 0)
        { setStatus (TR ("Клип уже совпадает с проектом — менять нечего"), 1.0f); return; }

        const int sr = settings.getProperty ("sampleRate", 48000);
        const int bits = settings.getProperty ("bitDepth", 24);
        const double pitch = std::pow (2.0, plan.semitones / 12.0);

        String tag;
        if (fitTempo && srcBpm > 0) tag << String (srcBpm * plan.tempoRatio, 1).trimCharactersAtEnd ("0").trimCharactersAtEnd (".") << "bpm";
        if (plan.semitones != 0)
        {
            const int newKey = srcKey >= 0 ? ((srcKey + plan.semitones) % 12 + 12) % 12 : -1;
            tag << (tag.isEmpty() ? "" : " ") << (newKey >= 0 ? lv::keyName (newKey, srcMinor) : String())
                << " " << (plan.semitones > 0 ? "+" : "") << plan.semitones << "st";
        }
        auto out = src.getSiblingFile (src.getFileNameWithoutExtension().upToLastOccurrenceOf (" {", false, false) + " {" + tag.trim() + "}.wav");

        auto ffArgs = [&] (const String& filter)
        {
            return StringArray { t.ffmpeg.getFullPathName(), "-hide_banner", "-y", "-i", src.getFullPathName(),
                                 "-af", filter, "-ar", String (sr), "-c:a", bits == 16 ? "pcm_s16le" : "pcm_s24le",
                                 out.getFullPathName() };
        };

        // 1) Rubber Band — лучшее качество (формантно-нейтральный time-stretch)
        const String rb = "rubberband=tempo=" + String (plan.tempoRatio, 6) + ":pitch=" + String (pitch, 6) + ":transients=crisp";
        int code = runner.run (ffArgs (rb), nullptr, nullptr);
        if (runner.wasKilled()) { setStatus (TR ("Остановлено"), 0); return; }

        // 2) запасной вариант: asetrate + atempo (есть в любом ffmpeg)
        if (code != 0)
        {
            const double inRate = clipRate;
            const String fb = "asetrate=" + String (inRate * pitch, 3) + ",aresample=" + String (inRate, 0) + ","
                            + atempoChain (plan.tempoRatio / pitch);
            String log;
            code = runner.run (ffArgs (fb), nullptr, &log);
            if (code != 0) { setStatus (TR ("Ошибка ffmpeg: ") + log.getLastCharacters (200), 0); return; }
        }
        loadClipNow (out);
    });
}

AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new LovetsProcessor(); }
