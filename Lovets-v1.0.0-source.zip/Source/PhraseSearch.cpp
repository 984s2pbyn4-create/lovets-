#include "PhraseSearch.h"

namespace lv
{
using namespace juce;

static juce_wchar lowerChar (juce_wchar c)
{
    if (c >= 'A' && c <= 'Z') return c + 32;
    if (c >= 0x410 && c <= 0x42F) return c + 0x20;          // А-Я
    if (c >= 0x400 && c <= 0x40F) return c + 0x50;          // Ѐ-Џ (Ё, Є, І, Ї …)
    if (c >= 0xC0 && c <= 0xDE && c != 0xD7) return c + 32; // Latin-1
    return CharacterFunctions::toLowerCase (c);
}

static bool isWordChar (juce_wchar c)
{
    if (c < 128) return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '\'';
    if (c >= 0x2000 && c <= 0x206F) return false; // типографская пунктуация «—…“”
    if (c == 0xAB || c == 0xBB || c == 0xA0) return false;
    return true;
}

String normaliseWord (const String& w)
{
    String r;
    for (auto p = w.getCharPointer(); ! p.isEmpty(); ++p)
    {
        auto c = *p;
        if (! isWordChar (c) || c == '\'') continue;
        c = lowerChar (c);
        if (c == 0x451) c = 0x435; // ё -> е
        r += String::charToString (c);
    }
    return r;
}

StringArray tokenise (const String& text)
{
    StringArray out;
    String cur;
    for (auto p = text.getCharPointer(); ! p.isEmpty(); ++p)
    {
        if (isWordChar (*p)) cur += String::charToString (*p);
        else if (cur.isNotEmpty()) { auto n = normaliseWord (cur); if (n.isNotEmpty()) out.add (n); cur.clear(); }
    }
    if (cur.isNotEmpty()) { auto n = normaliseWord (cur); if (n.isNotEmpty()) out.add (n); }
    return out;
}

static StringArray rawWords (const String& text)
{
    StringArray out;
    out.addTokens (text.replaceCharacters ("\n\r\t", "   "), " ", "");
    out.removeEmptyStrings();
    return out;
}

static void pushWord (std::vector<Word>& words, const String& text, double st, double en)
{
    auto parts = tokenise (text); // "что-то" -> что, то (как и во фразе)
    for (int i = 0; i < parts.size(); ++i)
    {
        Word w;
        w.text = parts.size() == 1 ? text : parts[i];
        w.norm = parts[i];
        w.start = st + (en - st) * i / parts.size();
        w.end = st + (en - st) * (i + 1) / parts.size();
        words.push_back (w);
    }
}

std::vector<Word> parseJson3 (const String& json)
{
    std::vector<Word> words;
    auto root = JSON::parse (json);
    auto* events = root.getProperty ("events", var()).getArray();
    if (events == nullptr) return words;

    for (auto& ev : *events)
    {
        auto* segs = ev.getProperty ("segs", var()).getArray();
        if (segs == nullptr) continue;
        const double t0 = (double) ev.getProperty ("tStartMs", 0) / 1000.0;
        const double dur = jmax (0.2, (double) ev.getProperty ("dDurationMs", 2000) / 1000.0);

        bool hasOffsets = false;
        for (auto& s : *segs) if (s.hasProperty ("tOffsetMs")) hasOffsets = true;

        if (hasOffsets) // автосубтитры: пословные отметки времени
        {
            for (int i = 0; i < segs->size(); ++i)
            {
                const auto& s = segs->getReference (i);
                const double st = t0 + (double) s.getProperty ("tOffsetMs", 0) / 1000.0;
                const double en = (i + 1 < segs->size())
                                      ? t0 + (double) segs->getReference (i + 1).getProperty ("tOffsetMs", 0) / 1000.0
                                      : t0 + dur;
                auto ws = rawWords (s.getProperty ("utf8", "").toString());
                for (int k = 0; k < ws.size(); ++k)
                    pushWord (words, ws[k], st + (en - st) * k / ws.size(), st + (en - st) * (k + 1) / ws.size());
            }
        }
        else // ручные субтитры: распределяем по длине текста
        {
            String all;
            for (auto& s : *segs) all << s.getProperty ("utf8", "").toString();
            auto ws = rawWords (all);
            int totalChars = 0;
            for (auto& w : ws) totalChars += w.length() + 1;
            int pos = 0;
            for (auto& t : ws)
            {
                const double st = t0 + dur * pos / jmax (1, totalChars);
                pos += t.length() + 1;
                pushWord (words, t, st, t0 + dur * pos / jmax (1, totalChars));
            }
        }
    }
    std::stable_sort (words.begin(), words.end(), [] (const Word& a, const Word& b) { return a.start < b.start; });
    return words;
}

std::vector<Hit> findPhrase (const std::vector<Word>& words, const StringArray& phrase)
{
    std::vector<Hit> hits;
    const int n = phrase.size();
    if (n == 0) return hits;
    double lastStart = -100;
    for (size_t i = 0; i + (size_t) n <= words.size(); ++i)
    {
        bool ok = true;
        for (int k = 0; k < n && ok; ++k)
        {
            const auto& w = words[i + (size_t) k].norm;
            // допускаем окончания для слов от 4 букв (привет -> приветик, друг -> друга)
            ok = w == phrase[k] || (phrase[k].length() >= 4 && w.startsWith (phrase[k]) && w.length() <= phrase[k].length() + 3);
        }
        if (! ok) continue;
        Hit h;
        h.start = words[i].start;
        h.end = words[i + (size_t) n - 1].end;
        if (h.start - lastStart < 1.0) continue; // дубликаты (перекрывающиеся строки автосубтитров)
        lastStart = h.start;
        String ctx;
        for (size_t k = (size_t) jmax (0, (int) i - 5); k < jmin (words.size(), i + (size_t) n + 5); ++k)
        {
            const bool inside = k >= i && k < i + (size_t) n;
            ctx << (inside ? "[" : "") << words[k].text << (inside ? "]" : "") << " ";
        }
        h.context = ctx.replace ("] [", " ").trim();
        hits.push_back (h);
    }
    return hits;
}

void runPhraseSearch (const String& phrase, const String& lang, int maxVideos,
                      const ToolPaths& tools, const String& cookies,
                      ProcessRunner& runner, const SearchCallbacks& cb)
{
    const auto tokens = tokenise (phrase);
    if (tokens.isEmpty()) { cb.status (TR ("Введите фразу"), 0); return; }

    cb.status (TR ("Ищу ролики на YouTube…"), -1.0f);
    auto args = ytdlpBase (tools, cookies);
    args.removeString ("--no-playlist");
    args.addArray ({ "--flat-playlist", "-J", "ytsearch" + String (maxVideos) + ":\"" + phrase.trim() + "\"" });
    String out;
    int code = runner.run (args, nullptr, &out);
    if (runner.wasKilled()) { cb.status (TR ("Остановлено"), 0); return; }

    auto jsonStart = out.indexOfChar ('{');
    auto root = jsonStart >= 0 ? JSON::parse (out.substring (jsonStart)) : var();
    auto* entries = root.getProperty ("entries", var()).getArray();
    if (code != 0 || entries == nullptr)
    {
        cb.status (TR ("Ошибка поиска: ") + out.fromLastOccurrenceOf ("ERROR:", false, false).trim().substring (0, 200), 0);
        return;
    }

    auto work = tempDir().getChildFile ("subs");
    work.deleteRecursively();
    work.createDirectory();

    int done = 0, found = 0;
    for (auto& e : *entries)
    {
        if (runner.wasKilled()) break;
        const String id = e.getProperty ("id", "").toString();
        const String title = e.getProperty ("title", id).toString();
        const String channel = e.getProperty ("channel", e.getProperty ("uploader", "")).toString();
        ++done;
        cb.status (TR ("Субтитры ") + String (done) + "/" + String (entries->size()) + ": " + title.substring (0, 50),
                   (float) done / (float) entries->size());
        if (id.isEmpty()) continue;

        auto a = ytdlpBase (tools, cookies);
        a.addArray ({ "--skip-download", "--write-info-json", "--write-subs", "--write-auto-subs",
                      "--sub-langs", lang + "," + lang + "-orig", "--sub-format", "json3",
                      "-o", work.getChildFile (id).getFullPathName() + ".%(ext)s",
                      "https://www.youtube.com/watch?v=" + id });
        runner.run (a, nullptr, nullptr);

        // выбираем дорожку: ручные > автосубтитры оригинала; машинный перевод отбрасываем
        auto info = JSON::parse (work.getChildFile (id + ".info.json"));
        const bool manual = info.getProperty ("subtitles", var()).hasProperty (lang);
        const String vLang = info.getProperty ("language", "").toString();
        File subs;
        if (manual) subs = work.getChildFile (id + "." + lang + ".json3");
        else if (work.getChildFile (id + "." + lang + "-orig.json3").existsAsFile())
            subs = work.getChildFile (id + "." + lang + "-orig.json3");
        else if (vLang.startsWith (lang) && work.getChildFile (id + "." + lang + ".json3").existsAsFile())
            subs = work.getChildFile (id + "." + lang + ".json3");
        if (! subs.existsAsFile()) continue;

        for (auto h : findPhrase (parseJson3 (subs.loadFileAsString()), tokens))
        {
            h.videoId = id;
            h.title = title;
            h.channel = channel;
            h.autoCaptions = ! manual;
            cb.hit (h);
            ++found;
        }
    }
    work.deleteRecursively();
    cb.status (runner.wasKilled() ? TR ("Остановлено. Найдено моментов: ") + String (found)
                                  : TR ("Готово. Проверено роликов: ") + String (done) + TR (", найдено моментов: ") + String (found),
               1.0f);
}
}
