#include "PluginEditor.h"

using namespace juce;

const Colour LovetsLook::bg     { 0xff121418 };
const Colour LovetsLook::panel  { 0xff1c1f26 };
const Colour LovetsLook::accent { 0xffff7a1a };
const Colour LovetsLook::text   { 0xffe8e8ea };
const Colour LovetsLook::dim    { 0xff8a8f99 };

LovetsLook::LovetsLook()
{
    setColour (ResizableWindow::backgroundColourId, bg);
    setColour (TextButton::buttonColourId, Colour (0xff2a2e38));
    setColour (TextButton::buttonOnColourId, accent);
    setColour (TextButton::textColourOffId, text);
    setColour (TextButton::textColourOnId, Colours::black);
    setColour (TextEditor::backgroundColourId, Colour (0xff0d0f12));
    setColour (TextEditor::outlineColourId, Colour (0xff343946));
    setColour (TextEditor::focusedOutlineColourId, accent);
    setColour (TextEditor::textColourId, text);
    setColour (ComboBox::backgroundColourId, Colour (0xff0d0f12));
    setColour (ComboBox::outlineColourId, Colour (0xff343946));
    setColour (ComboBox::textColourId, text);
    setColour (ComboBox::arrowColourId, accent);
    setColour (PopupMenu::backgroundColourId, panel);
    setColour (PopupMenu::highlightedBackgroundColourId, accent);
    setColour (Label::textColourId, text);
    setColour (ListBox::backgroundColourId, Colour (0xff0d0f12));
    setColour (Slider::thumbColourId, accent);
    setColour (Slider::trackColourId, accent.withAlpha (0.6f));
    setColour (Slider::backgroundColourId, Colour (0xff2a2e38));
    setColour (Slider::textBoxTextColourId, text);
    setColour (Slider::textBoxOutlineColourId, Colour (0xff343946));
    setColour (ToggleButton::textColourId, text);
    setColour (ToggleButton::tickColourId, accent);
    setColour (ProgressBar::foregroundColourId, accent);
    setColour (ProgressBar::backgroundColourId, Colour (0xff0d0f12));
}

// ================================================================== ClipView
ClipView::ClipView (LovetsProcessor& p) : proc (p), thumb (512, p.formats, cache)
{
    thumb.addChangeListener (this);
    setMouseCursor (MouseCursor::DraggingHandCursor);
}
ClipView::~ClipView() { thumb.removeChangeListener (this); }

void ClipView::setFile (const File& f)
{
    file = f;
    thumb.setSource (f.existsAsFile() ? new FileInputSource (f) : nullptr);
    repaint();
}

void ClipView::paint (Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    g.setColour (Colour (0xff0d0f12));
    g.fillRoundedRectangle (r, 6);
    g.setColour (LovetsLook::accent.withAlpha (0.45f));
    g.drawRoundedRectangle (r.reduced (0.5f), 6, 1);

    if (thumb.getTotalLength() > 0)
    {
        g.setColour (LovetsLook::accent.withAlpha (0.85f));
        thumb.drawChannels (g, getLocalBounds().reduced (6, 18), 0, thumb.getTotalLength(), 0.9f);
        if (proc.playing)
        {
            const float x = (float) (6 + (getWidth() - 12) * proc.playFraction());
            g.setColour (Colours::white);
            g.drawVerticalLine ((int) x, 4.0f, (float) getHeight() - 4.0f);
        }
        g.setColour (LovetsLook::text);
        g.setFont (FontOptions (12.0f));
        g.drawText (TR ("⇣ Перетащите волну на дорожку DAW"), getLocalBounds().reduced (8, 2), Justification::bottomRight);
    }
    else
    {
        g.setColour (LovetsLook::dim);
        g.setFont (FontOptions (14.0f));
        g.drawText (TR ("Здесь появится скачанный WAV — его можно перетащить в DAW.\nСюда же можно бросить свой WAV/MP3 для анализа BPM и тональности."),
                    getLocalBounds().reduced (10), Justification::centred);
    }
}

void ClipView::mouseDown (const MouseEvent&) { dragStarted = false; }

void ClipView::mouseDrag (const MouseEvent& e)
{
    if (dragStarted || ! file.existsAsFile() || e.getDistanceFromDragStart() < 6) return;
    dragStarted = true;
    DragAndDropContainer::performExternalDragDropOfFiles ({ file.getFullPathName() }, false, this);
}

// ================================================================== Editor
static void styleLabel (Label& l, const String& t, float size = 14.0f, Colour c = LovetsLook::text)
{
    l.setText (t, dontSendNotification);
    l.setFont (FontOptions (size));
    l.setColour (Label::textColourId, c);
}

LovetsEditor::LovetsEditor (LovetsProcessor& p) : AudioProcessorEditor (p), proc (p), clipView (p)
{
    setLookAndFeel (&look);

    const String tabNames[] = { TR ("Скачать WAV"), TR ("Поиск фразы"), TR ("BPM и тональность"), TR ("Настройки") };
    for (int i = 0; i < 4; ++i)
    {
        auto* b = tabButtons.add (new TextButton (tabNames[i]));
        b->setClickingTogglesState (false);
        b->onClick = [this, i] { showTab (i); };
        addAndMakeVisible (b);
    }

    // ---------- Скачать
    styleLabel (urlLabel, TR ("Ссылка на видео YouTube:"));
    urlEdit.setTextToShowWhenEmpty (TR ("https://www.youtube.com/watch?v=…"), LovetsLook::dim);
    styleLabel (rangeLabel, TR ("Фрагмент (необязательно), начало и конец — 1:23 или 83.5:"));
    startEdit.setTextToShowWhenEmpty (TR ("начало"), LovetsLook::dim);
    endEdit.setTextToShowWhenEmpty (TR ("конец"), LovetsLook::dim);
    styleLabel (dlHint, TR ("WAV сохраняется в папку из «Настроек», сразу открывается ниже, анализируется (BPM, тональность) "
                        "и готов к перетаскиванию в DAW. Используйте только материал, на который у вас есть права."), 13.0f, LovetsLook::dim);
    dlHint.setJustificationType (Justification::topLeft);
    downloadBtn.setColour (TextButton::buttonColourId, LovetsLook::accent);
    downloadBtn.setColour (TextButton::textColourOffId, Colours::black);
    downloadBtn.onClick = [this]
    {
        proc.downloadUrl (urlEdit.getText(), lv::parseTime (startEdit.getText()), lv::parseTime (endEdit.getText()));
    };
    pasteBtn.onClick = [this] { urlEdit.setText (SystemClipboard::getTextFromClipboard().trim()); };
    urlEdit.onReturnKey = [this] { downloadBtn.triggerClick(); };

    // ---------- Поиск
    phraseEdit.setTextToShowWhenEmpty (TR ("Фраза, например: привет"), LovetsLook::dim);
    phraseEdit.onReturnKey = [this] { searchBtn.triggerClick(); };
    const std::pair<const char*, String> langs[] = { { "ru", TR ("Русский") }, { "en", "English" }, { "uk", TR ("Українська") },
        { "de", "Deutsch" }, { "es", TR ("Español") }, { "fr", TR ("Français") }, { "it", "Italiano" }, { "pt", TR ("Português") },
        { "ja", TR ("日本語") }, { "ko", TR ("한국어") } };
    int id = 1;
    for (auto& l : langs) langBox.addItem (l.second, id++);
    const String savedLang = proc.getSetting ("lang", "ru");
    for (int i = 0; i < (int) std::size (langs); ++i) if (savedLang == langs[i].first) langBox.setSelectedId (i + 1, dontSendNotification);
    for (int n : { 5, 10, 20, 30, 50 }) countBox.addItem (String (n) + TR (" роликов"), n);
    countBox.setSelectedId ((int) proc.settings.getProperty ("maxVideos", 10), dontSendNotification);
    searchBtn.setColour (TextButton::buttonColourId, LovetsLook::accent);
    searchBtn.setColour (TextButton::textColourOffId, Colours::black);
    searchBtn.onClick = [this, langs]
    {
        const String code = langs[jmax (0, langBox.getSelectedId() - 1)].first;
        proc.settings.setProperty ("lang", code, nullptr);
        proc.settings.setProperty ("maxVideos", countBox.getSelectedId(), nullptr);
        proc.searchPhrase (phraseEdit.getText(), code, countBox.getSelectedId());
    };
    for (auto* s : { &padBefore, &padAfter })
    {
        s->setSliderStyle (Slider::LinearHorizontal);
        s->setTextBoxStyle (Slider::TextBoxRight, false, 56, 22);
        s->setRange (0.0, 5.0, 0.05);
        s->setTextValueSuffix (TR (" с"));
    }
    padBefore.setValue ((double) proc.settings.getProperty ("padBefore", 0.3), dontSendNotification);
    padAfter.setValue ((double) proc.settings.getProperty ("padAfter", 0.5), dontSendNotification);
    padBefore.onValueChange = [this] { proc.settings.setProperty ("padBefore", padBefore.getValue(), nullptr); };
    padAfter.onValueChange = [this] { proc.settings.setProperty ("padAfter", padAfter.getValue(), nullptr); };
    styleLabel (padBeforeLbl, TR ("Запас до:"), 13);
    styleLabel (padAfterLbl, TR ("Запас после:"), 13);
    styleLabel (searchHint, TR ("Плагин берёт первые N роликов из поиска YouTube, читает их субтитры (ручные или автоматические) "
                            "и показывает точные моменты фразы. Двойной клик — скачать момент в WAV."), 12.5f, LovetsLook::dim);
    hitList.setRowHeight (46);
    hitFragBtn.onClick = [this] { if (auto* h = selectedHit()) proc.downloadHit (*h, false); };
    hitFullBtn.onClick = [this] { if (auto* h = selectedHit()) proc.downloadHit (*h, true); };
    hitOpenBtn.onClick = [this] { if (auto* h = selectedHit()) URL (h->url()).launchInDefaultBrowser(); };

    // ---------- BPM / тональность
    styleLabel (srcTitle, TR ("ИСХОДНИК (клип)"), 13, LovetsLook::accent);
    styleLabel (dstTitle, TR ("ПРОЕКТ (цель)"), 13, LovetsLook::accent);
    styleLabel (srcBpmLbl, "BPM:");
    styleLabel (srcKeyLbl, TR ("Тональность:"));
    styleLabel (dstBpmLbl, "BPM:");
    styleLabel (dstKeyLbl, TR ("Тональность:"));
    styleLabel (hostLbl, "", 12.5f, LovetsLook::dim);
    styleLabel (semisLbl, TR ("Доп. сдвиг, полутоны:"));
    styleLabel (fitInfo, "", 13.5f);
    fitInfo.setJustificationType (Justification::topLeft);
    fillKeyBox (srcKeyBox, false);
    fillKeyBox (dstKeyBox, false);
    dstKeyBox.setSelectedId ((int) proc.settings.getProperty ("dstKey", 1), dontSendNotification);
    dstBpmEdit.setText (proc.getSetting ("dstBpm", "120"));
    useHostBpm.setToggleState ((bool) proc.settings.getProperty ("useHost", true), dontSendNotification);
    fitTempoTgl.setToggleState (true, dontSendNotification);
    fitKeyTgl.setToggleState (true, dontSendNotification);
    semisSlider.setSliderStyle (Slider::LinearHorizontal);
    semisSlider.setTextBoxStyle (Slider::TextBoxRight, false, 50, 22);
    semisSlider.setRange (-12, 12, 1);
    semisSlider.setValue (0, dontSendNotification);
    halfBtn.onClick = [this] { srcBpmEdit.setText (String (srcBpmEdit.getText().getDoubleValue() / 2.0, 1)); };
    doubleBtn.onClick = [this] { srcBpmEdit.setText (String (srcBpmEdit.getText().getDoubleValue() * 2.0, 1)); };
    reanalyseBtn.onClick = [this] { if (proc.getClipFile().existsAsFile()) proc.loadClip (proc.getClipFile()); };
    fitBtn.setColour (TextButton::buttonColourId, LovetsLook::accent);
    fitBtn.setColour (TextButton::textColourOffId, Colours::black);
    fitBtn.onClick = [this]
    {
        const double dst = (useHostBpm.getToggleState() && proc.hostBpm > 0) ? proc.hostBpm.load() : dstBpmEdit.getText().getDoubleValue();
        proc.settings.setProperty ("dstBpm", dstBpmEdit.getText(), nullptr);
        proc.settings.setProperty ("dstKey", dstKeyBox.getSelectedId(), nullptr);
        proc.settings.setProperty ("useHost", useHostBpm.getToggleState(), nullptr);
        const int s = srcKeyBox.getSelectedId() - 1, d = dstKeyBox.getSelectedId() - 1;
        proc.fitClip (srcBpmEdit.getText().getDoubleValue(), dst, s >= 0 ? s / 2 : -1, s % 2 == 1,
                      d >= 0 ? d / 2 : -1, d % 2 == 1, fitTempoTgl.getToggleState(), fitKeyTgl.getToggleState(),
                      (int) semisSlider.getValue());
    };

    // ---------- Настройки
    styleLabel (toolsLbl, "", 13.5f);
    toolsLbl.setJustificationType (Justification::topLeft);
    styleLabel (outLbl, "", 13.5f);
    styleLabel (rateLbl, TR ("Частота WAV:"));
    styleLabel (bitsLbl, TR ("Разрядность:"));
    styleLabel (cookiesLbl, "", 12.5f, LovetsLook::dim);
    styleLabel (aboutLbl, String::fromUTF8 ("ЛОВЕЦ v" LOVETS_VERSION "  —  " LOVETS_AUTHOR "\n"
                                            "Загрузка: yt-dlp + ffmpeg, BPM: автокорреляция атак, тональность: профили Крумхансла, "
                                            "подгонка: Rubber Band (ffmpeg). Если YouTube просит подтвердить, что вы не бот, укажите файл cookies "
                                            "(экспорт из браузера в формате Netscape)."), 12.5f, LovetsLook::dim);
    aboutLbl.setJustificationType (Justification::topLeft);
    rateBox.addItem (TR ("44100 Гц"), 44100);
    rateBox.addItem (TR ("48000 Гц"), 48000);
    rateBox.setSelectedId ((int) proc.settings.getProperty ("sampleRate", 48000), dontSendNotification);
    rateBox.onChange = [this] { proc.settings.setProperty ("sampleRate", rateBox.getSelectedId(), nullptr); };
    bitsBox.addItem (TR ("16 бит"), 16);
    bitsBox.addItem (TR ("24 бит"), 24);
    bitsBox.setSelectedId ((int) proc.settings.getProperty ("bitDepth", 24), dontSendNotification);
    bitsBox.onChange = [this] { proc.settings.setProperty ("bitDepth", bitsBox.getSelectedId(), nullptr); };
    installBtn.setColour (TextButton::buttonColourId, LovetsLook::accent);
    installBtn.setColour (TextButton::textColourOffId, Colours::black);
    installBtn.onClick = [this] { proc.installTools(); };
    recheckBtn.onClick = [this] { proc.refreshTools(); };
    outBtn.onClick = [this]
    {
        chooser = std::make_unique<FileChooser> (TR ("Папка для WAV"), proc.outputDir());
        chooser->launchAsync (FileBrowserComponent::openMode | FileBrowserComponent::canSelectDirectories, [this] (const FileChooser& fc)
        {
            if (fc.getResult().isDirectory()) proc.settings.setProperty ("outputDir", fc.getResult().getFullPathName(), nullptr);
        });
    };
    cookiesBtn.onClick = [this]
    {
        chooser = std::make_unique<FileChooser> (TR ("cookies.txt (формат Netscape)"), File::getSpecialLocation (File::userHomeDirectory), "*.txt");
        chooser->launchAsync (FileBrowserComponent::openMode | FileBrowserComponent::canSelectFiles, [this] (const FileChooser& fc)
        {
            if (fc.getResult().existsAsFile()) proc.settings.setProperty ("cookies", fc.getResult().getFullPathName(), nullptr);
        });
    };
    cookiesClearBtn.onClick = [this] { proc.settings.setProperty ("cookies", "", nullptr); };

    // ---------- низ
    styleLabel (clipInfo, "", 14.0f);
    styleLabel (statusLbl, "", 13.0f, LovetsLook::dim);
    playBtn.onClick = [this]
    {
        if (! proc.playing && proc.playPos.load() <= 0) proc.playPos = 0;
        proc.playing = ! proc.playing.load();
        if (! proc.playing) proc.playPos = 0;
    };
    revealBtn.onClick = [this]
    {
        auto f = proc.getClipFile();
        if (f.existsAsFile()) f.revealToUser(); else proc.outputDir().revealToUser();
    };
    cancelBtn.onClick = [this] { proc.cancel(); };
    gainSlider.setSliderStyle (Slider::LinearHorizontal);
    gainSlider.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
    gainSlider.setRange (0, 1, 0.01);
    gainSlider.setValue (proc.previewGain.load(), dontSendNotification);
    gainSlider.onValueChange = [this] { proc.previewGain = (float) gainSlider.getValue(); };
    gainSlider.setTooltip (TR ("Громкость предпрослушки"));

    Component* all[] = { &urlLabel, &urlEdit, &pasteBtn, &rangeLabel, &startEdit, &endEdit, &downloadBtn, &dlHint,
                         &phraseEdit, &langBox, &countBox, &searchBtn, &padBeforeLbl, &padBefore, &padAfterLbl, &padAfter,
                         &searchHint, &hitList, &hitFragBtn, &hitFullBtn, &hitOpenBtn,
                         &srcTitle, &dstTitle, &srcBpmLbl, &srcKeyLbl, &dstBpmLbl, &dstKeyLbl, &hostLbl, &semisLbl, &fitInfo,
                         &srcBpmEdit, &dstBpmEdit, &srcKeyBox, &dstKeyBox, &useHostBpm, &fitTempoTgl, &fitKeyTgl, &semisSlider,
                         &halfBtn, &doubleBtn, &reanalyseBtn, &fitBtn,
                         &toolsLbl, &outLbl, &rateLbl, &bitsLbl, &cookiesLbl, &aboutLbl, &installBtn, &recheckBtn, &outBtn,
                         &cookiesBtn, &cookiesClearBtn, &rateBox, &bitsBox,
                         &clipView, &clipInfo, &statusLbl, &playBtn, &revealBtn, &cancelBtn, &gainSlider, &progress };
    for (auto* c : all) addChildComponent (c);
    for (Component* c : { (Component*) &clipView, (Component*) &clipInfo, (Component*) &statusLbl, (Component*) &playBtn,
                          (Component*) &revealBtn, (Component*) &cancelBtn, (Component*) &gainSlider, (Component*) &progress })
        c->setVisible (true);

    setResizable (true, true);
    setResizeLimits (760, 560, 1600, 1200);
    setSize (920, 640);
    showTab (proc.toolsReady() ? 0 : 3);
    startTimerHz (15);
}

LovetsEditor::~LovetsEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

void LovetsEditor::fillKeyBox (ComboBox& b, bool)
{
    static const char* names[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    for (int k = 0; k < 12; ++k)
    {
        b.addItem (String (names[k]) + TR (" мажор  (") + lv::camelot (k, false) + ")", k * 2 + 1);
        b.addItem (String (names[k]) + TR ("m минор  (") + lv::camelot (k, true) + ")", k * 2 + 2);
    }
}

void LovetsEditor::showTab (int t)
{
    currentTab = t;
    for (int i = 0; i < tabButtons.size(); ++i)
    {
        tabButtons[i]->setToggleState (i == t, dontSendNotification);
        tabButtons[i]->setColour (TextButton::buttonColourId, i == t ? LovetsLook::panel : Colour (0xff15171c));
        tabButtons[i]->setColour (TextButton::textColourOffId, i == t ? LovetsLook::accent : LovetsLook::dim);
    }
    std::vector<std::vector<Component*>> groups {
        { &urlLabel, &urlEdit, &pasteBtn, &rangeLabel, &startEdit, &endEdit, &downloadBtn, &dlHint },
        { &phraseEdit, &langBox, &countBox, &searchBtn, &padBeforeLbl, &padBefore, &padAfterLbl, &padAfter, &searchHint,
          &hitList, &hitFragBtn, &hitFullBtn, &hitOpenBtn },
        { &srcTitle, &dstTitle, &srcBpmLbl, &srcKeyLbl, &dstBpmLbl, &dstKeyLbl, &hostLbl, &semisLbl, &fitInfo, &srcBpmEdit,
          &dstBpmEdit, &srcKeyBox, &dstKeyBox, &useHostBpm, &fitTempoTgl, &fitKeyTgl, &semisSlider, &halfBtn, &doubleBtn,
          &reanalyseBtn, &fitBtn },
        { &toolsLbl, &outLbl, &rateLbl, &bitsLbl, &cookiesLbl, &aboutLbl, &installBtn, &recheckBtn, &outBtn, &cookiesBtn,
          &cookiesClearBtn, &rateBox, &bitsBox } };
    for (int g = 0; g < (int) groups.size(); ++g)
        for (auto* c : groups[(size_t) g]) c->setVisible (g == t);
    resized();
    repaint();
}

void LovetsEditor::paint (Graphics& g)
{
    g.fillAll (LovetsLook::bg);
    auto r = getLocalBounds();
    auto header = r.removeFromTop (56).reduced (16, 0);
    g.setColour (LovetsLook::accent);
    g.setFont (FontOptions (28.0f, Font::bold));
    g.drawText (String::fromUTF8 ("ЛОВЕЦ"), header.removeFromLeft (130), Justification::centredLeft);
    g.setColour (LovetsLook::dim);
    g.setFont (FontOptions (13.0f));
    g.drawText (String::fromUTF8 ("YouTube → WAV  •  поиск фраз  •  BPM и тональность"), header.removeFromLeft (420), Justification::centredLeft);
    g.setColour (LovetsLook::text);
    g.setFont (FontOptions (15.0f, Font::bold));
    g.drawText (LOVETS_AUTHOR, header, Justification::centredRight);

    g.setColour (LovetsLook::panel);
    g.fillRoundedRectangle (getLocalBounds().withTrimmedTop (92).withTrimmedBottom (196).reduced (12, 0).toFloat(), 8);
}

void LovetsEditor::resized()
{
    auto r = getLocalBounds();
    r.removeFromTop (56);
    auto tabs = r.removeFromTop (36).reduced (12, 0);
    const int tw = tabs.getWidth() / jmax (1, tabButtons.size());
    for (auto* b : tabButtons) b->setBounds (tabs.removeFromLeft (tw).reduced (2, 0));

    // низ
    auto bottom = r.removeFromBottom (196).reduced (12, 8);
    auto status = bottom.removeFromBottom (26);
    cancelBtn.setBounds (status.removeFromRight (70));
    status.removeFromRight (6);
    progress.setBounds (status.removeFromRight (200).reduced (0, 3));
    statusLbl.setBounds (status);
    bottom.removeFromBottom (6);
    auto info = bottom.removeFromTop (28);
    playBtn.setBounds (info.removeFromLeft (110));
    info.removeFromLeft (6);
    gainSlider.setBounds (info.removeFromLeft (110));
    revealBtn.setBounds (info.removeFromRight (150));
    clipInfo.setBounds (info.reduced (8, 0));
    bottom.removeFromTop (6);
    clipView.setBounds (bottom);

    auto area = r.reduced (24, 14);
    switch (currentTab)
    {
        case 0: layoutDownload (area); break;
        case 1: layoutSearch (area); break;
        case 2: layoutFit (area); break;
        default: layoutSettings (area); break;
    }
}

void LovetsEditor::layoutDownload (Rectangle<int> a)
{
    urlLabel.setBounds (a.removeFromTop (24));
    auto row = a.removeFromTop (32);
    pasteBtn.setBounds (row.removeFromRight (100));
    row.removeFromRight (6);
    urlEdit.setBounds (row);
    a.removeFromTop (12);
    rangeLabel.setBounds (a.removeFromTop (24));
    row = a.removeFromTop (32);
    startEdit.setBounds (row.removeFromLeft (110));
    row.removeFromLeft (8);
    endEdit.setBounds (row.removeFromLeft (110));
    row.removeFromLeft (16);
    downloadBtn.setBounds (row.removeFromLeft (200));
    a.removeFromTop (12);
    dlHint.setBounds (a);
}

void LovetsEditor::layoutSearch (Rectangle<int> a)
{
    auto row = a.removeFromTop (32);
    searchBtn.setBounds (row.removeFromRight (110));
    row.removeFromRight (6);
    countBox.setBounds (row.removeFromRight (120));
    row.removeFromRight (6);
    langBox.setBounds (row.removeFromRight (130));
    row.removeFromRight (6);
    phraseEdit.setBounds (row);
    a.removeFromTop (6);
    row = a.removeFromTop (26);
    padBeforeLbl.setBounds (row.removeFromLeft (70));
    padBefore.setBounds (row.removeFromLeft (190));
    row.removeFromLeft (16);
    padAfterLbl.setBounds (row.removeFromLeft (90));
    padAfter.setBounds (row.removeFromLeft (190));
    auto btns = a.removeFromBottom (30);
    hitFragBtn.setBounds (btns.removeFromLeft (190));
    btns.removeFromLeft (6);
    hitFullBtn.setBounds (btns.removeFromLeft (110));
    btns.removeFromLeft (6);
    hitOpenBtn.setBounds (btns.removeFromLeft (160));
    a.removeFromBottom (6);
    searchHint.setBounds (a.removeFromTop (32));
    hitList.setBounds (a);
}

void LovetsEditor::layoutFit (Rectangle<int> a)
{
    auto btnRow = a.removeFromBottom (32);
    fitBtn.setBounds (btnRow.removeFromRight (240));
    btnRow.removeFromRight (8);
    reanalyseBtn.setBounds (btnRow.removeFromRight (190));
    a.removeFromBottom (6);

    auto left = a.removeFromLeft (a.getWidth() / 2).reduced (0, 0);
    auto right = a.withTrimmedLeft (16);

    srcTitle.setBounds (left.removeFromTop (22));
    auto row = left.removeFromTop (30);
    srcBpmLbl.setBounds (row.removeFromLeft (100));
    srcBpmEdit.setBounds (row.removeFromLeft (80));
    row.removeFromLeft (6);
    halfBtn.setBounds (row.removeFromLeft (36));
    row.removeFromLeft (4);
    doubleBtn.setBounds (row.removeFromLeft (36));
    left.removeFromTop (6);
    row = left.removeFromTop (30);
    srcKeyLbl.setBounds (row.removeFromLeft (100));
    srcKeyBox.setBounds (row.removeFromLeft (200));
    left.removeFromTop (10);
    fitInfo.setBounds (left);

    dstTitle.setBounds (right.removeFromTop (22));
    row = right.removeFromTop (30);
    dstBpmLbl.setBounds (row.removeFromLeft (100));
    dstBpmEdit.setBounds (row.removeFromLeft (80));
    row.removeFromLeft (8);
    useHostBpm.setBounds (row);
    hostLbl.setBounds (right.removeFromTop (20).withTrimmedLeft (100));
    row = right.removeFromTop (30);
    dstKeyLbl.setBounds (row.removeFromLeft (100));
    dstKeyBox.setBounds (row.removeFromLeft (200));
    right.removeFromTop (6);
    fitTempoTgl.setBounds (right.removeFromTop (26));
    fitKeyTgl.setBounds (right.removeFromTop (26));
    row = right.removeFromTop (28);
    semisLbl.setBounds (row.removeFromLeft (160));
    semisSlider.setBounds (row);
}

void LovetsEditor::layoutSettings (Rectangle<int> a)
{
    auto row = a.removeFromTop (32);
    installBtn.setBounds (row.removeFromLeft (290));
    row.removeFromLeft (8);
    recheckBtn.setBounds (row.removeFromLeft (150));
    a.removeFromTop (4);
    toolsLbl.setBounds (a.removeFromTop (60));
    row = a.removeFromTop (30);
    outBtn.setBounds (row.removeFromLeft (160));
    outLbl.setBounds (row.withTrimmedLeft (10));
    a.removeFromTop (6);
    row = a.removeFromTop (30);
    rateLbl.setBounds (row.removeFromLeft (100));
    rateBox.setBounds (row.removeFromLeft (120));
    row.removeFromLeft (20);
    bitsLbl.setBounds (row.removeFromLeft (100));
    bitsBox.setBounds (row.removeFromLeft (100));
    a.removeFromTop (6);
    row = a.removeFromTop (30);
    cookiesBtn.setBounds (row.removeFromLeft (140));
    row.removeFromLeft (6);
    cookiesClearBtn.setBounds (row.removeFromLeft (90));
    cookiesLbl.setBounds (row.withTrimmedLeft (10));
    a.removeFromTop (6);
    aboutLbl.setBounds (a);
}

// ------------------------------------------------------------------ список результатов
void LovetsEditor::paintListBoxItem (int row, Graphics& g, int w, int h, bool selected)
{
    if (row < 0 || row >= (int) hits.size()) return;
    const auto& hit = hits[(size_t) row];
    g.fillAll (selected ? LovetsLook::accent.withAlpha (0.25f) : (row % 2 ? Colour (0xff14161b) : Colour (0xff0d0f12)));
    g.setColour (LovetsLook::accent);
    g.setFont (FontOptions (15.0f, Font::bold));
    g.drawText (lv::formatTime (hit.start, true), 8, 0, 70, h, Justification::centredLeft);
    g.setColour (LovetsLook::text);
    g.setFont (FontOptions (13.5f));
    g.drawText (hit.title + (hit.channel.isNotEmpty() ? TR ("  —  ") + hit.channel : String()) + (hit.autoCaptions ? "" : TR ("  [ручные субтитры]")),
                84, 3, w - 92, 20, Justification::centredLeft, true);
    g.setColour (LovetsLook::dim);
    g.setFont (FontOptions (12.5f));
    g.drawText (TR ("…") + hit.context + TR ("…"), 84, 23, w - 92, 20, Justification::centredLeft, true);
}

void LovetsEditor::listBoxItemDoubleClicked (int row, const MouseEvent&)
{
    if (row >= 0 && row < (int) hits.size()) proc.downloadHit (hits[(size_t) row], false);
}

const lv::Hit* LovetsEditor::selectedHit() const
{
    const int r = hitList.getSelectedRow();
    return (r >= 0 && r < (int) hits.size()) ? &hits[(size_t) r] : nullptr;
}

// ------------------------------------------------------------------ прочее
void LovetsEditor::filesDropped (const StringArray& files, int, int)
{
    for (auto& f : files)
    {
        File file (f);
        if (file.hasFileExtension ("wav;aif;aiff;flac;mp3;ogg"))
        {
            proc.loadClip (file);
            showTab (2);
            return;
        }
    }
}

void LovetsEditor::updateAnalysisUi()
{
    auto a = proc.getAnalysis();
    auto f = proc.getClipFile();
    clipView.setFile (f);
    srcBpmEdit.setText (a.bpm > 0 ? String (a.bpm, 1) : String(), dontSendNotification);
    srcKeyBox.setSelectedId (a.key >= 0 ? a.key * 2 + (a.minor ? 2 : 1) : 0, dontSendNotification);
    clipInfo.setText (f.existsAsFile()
                          ? f.getFileName() + "   |   " + (a.bpm > 0 ? String (a.bpm, 1) + " BPM" : String ("BPM ?")) + "   |   "
                                + lv::keyName (a.key, a.minor) + " (" + lv::camelot (a.key, a.minor) + ")   |   "
                                + lv::formatTime (proc.getClipLength(), true)
                          : String(),
                      dontSendNotification);
}

void LovetsEditor::timerCallback()
{
    auto st = proc.getStatus();
    statusLbl.setText (st.text, dontSendNotification);
    progressValue = proc.isBusy() ? (double) st.progress : (st.progress >= 1.0f ? 1.0 : 0.0);
    cancelBtn.setEnabled (proc.isBusy());
    playBtn.setButtonText (proc.playing ? String::fromUTF8 ("■ Стоп") : String::fromUTF8 ("▶ Слушать"));

    if (proc.clipVersion != lastClipVersion) { lastClipVersion = proc.clipVersion; updateAnalysisUi(); }
    if (proc.hitsVersion != lastHitsVersion)
    {
        lastHitsVersion = proc.hitsVersion;
        const int sel = hitList.getSelectedRow();
        hits = proc.getHits();
        hitList.updateContent();
        hitList.selectRow (sel);
        hitList.repaint();
    }

    const double hb = proc.hostBpm.load();
    hostLbl.setText (hb > 0 ? TR ("Темп DAW: ") + String (hb, 1) + " BPM" : String (TR ("DAW не передаёт темп — введите вручную")), dontSendNotification);
    dstBpmEdit.setEnabled (! useHostBpm.getToggleState() || hb <= 0);

    if (currentTab == 2)
    {
        const double dst = (useHostBpm.getToggleState() && hb > 0) ? hb : dstBpmEdit.getText().getDoubleValue();
        const int s = srcKeyBox.getSelectedId() - 1, d = dstKeyBox.getSelectedId() - 1;
        auto plan = lv::planFit (srcBpmEdit.getText().getDoubleValue(), dst, s >= 0 ? s / 2 : -1, s % 2 == 1,
                                 d >= 0 ? d / 2 : -1, d % 2 == 1, fitTempoTgl.getToggleState(), fitKeyTgl.getToggleState());
        const int semis = plan.semitones + (int) semisSlider.getValue();
        fitInfo.setText (String (TR ("План обработки:\n"))
                         + TR ("• Темп: ×") + String (plan.tempoRatio, 3) + "  (" + String ((plan.tempoRatio - 1.0) * 100.0, 1) + "%)\n"
                         + TR ("• Высота: ") + (semis > 0 ? "+" : "") + String (semis) + TR (" полутонов\n")
                         + TR ("Половинный/двойной темп учитывается автоматически, лад приводится к относительному "
                           "(Am ↔ C). Результат сохраняется новым WAV рядом с исходником."),
                         dontSendNotification);
    }

    if (currentTab == 3)
    {
        toolsLbl.setText (proc.toolsSummary(), dontSendNotification);
        outLbl.setText (TR ("Папка: ") + proc.outputDir().getFullPathName(), dontSendNotification);
        const String c = proc.getSetting ("cookies", "");
        cookiesLbl.setText (c.isEmpty() ? String (TR ("cookies не заданы (обычно не нужны)")) : c, dontSendNotification);
    }

    if (proc.playing) clipView.repaint();
}
