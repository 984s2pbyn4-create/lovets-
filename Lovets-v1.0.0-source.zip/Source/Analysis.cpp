#include "Analysis.h"
#include <juce_dsp/juce_dsp.h>
#include <cmath>

namespace lv
{
static const char* noteNames[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };

juce::String keyName (int key, bool minor)
{
    if (key < 0 || key > 11) return "?";
    return juce::String (noteNames[key]) + (minor ? "m" : "");
}

juce::String camelot (int key, bool minor)
{
    if (key < 0 || key > 11) return "?";
    // мажор: C=8B, G=9B ... ; минор: Am=8A
    static const int majorNum[] = { 8, 3, 10, 5, 12, 7, 2, 9, 4, 11, 6, 1 };
    static const int minorNum[] = { 5, 12, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10 };
    return juce::String (minor ? minorNum[key] : majorNum[key]) + (minor ? "A" : "B");
}

AnalysisResult analyse (const juce::AudioBuffer<float>& buffer, double sampleRate)
{
    AnalysisResult r;
    const int n = buffer.getNumSamples();
    if (n < (int) (sampleRate * 2.0) || sampleRate <= 0) return r;

    // моно
    std::vector<float> mono ((size_t) n, 0.0f);
    for (int c = 0; c < buffer.getNumChannels(); ++c)
    {
        auto* d = buffer.getReadPointer (c);
        for (int i = 0; i < n; ++i) mono[(size_t) i] += d[i] / (float) buffer.getNumChannels();
    }

    constexpr int order = 12, fftSize = 1 << order, hop = 512;
    juce::dsp::FFT fft (order);
    juce::dsp::WindowingFunction<float> window (fftSize, juce::dsp::WindowingFunction<float>::hann, false);
    std::vector<float> frame ((size_t) fftSize * 2), prevMag ((size_t) fftSize / 2 + 1, 0.0f);
    std::vector<double> flux, chroma (12, 0.0);

    // таблица: бин -> класс высоты
    std::vector<int> binPc ((size_t) fftSize / 2 + 1, -1);
    for (int b = 1; b <= fftSize / 2; ++b)
    {
        const double f = b * sampleRate / fftSize;
        if (f < 50.0 || f > 5000.0) continue;
        const double midi = 69.0 + 12.0 * std::log2 (f / 440.0);
        binPc[(size_t) b] = ((int) std::lround (midi) % 12 + 12) % 12;
    }

    for (int start = 0; start + fftSize <= n; start += hop)
    {
        std::fill (frame.begin(), frame.end(), 0.0f);
        std::copy (mono.begin() + start, mono.begin() + start + fftSize, frame.begin());
        window.multiplyWithWindowingTable (frame.data(), (size_t) fftSize);
        fft.performFrequencyOnlyForwardTransform (frame.data(), true);

        double fl = 0.0;
        for (int b = 1; b <= fftSize / 2; ++b)
        {
            const float mag = frame[(size_t) b];
            const float lm = std::log1p (100.0f * mag);
            const float diff = lm - prevMag[(size_t) b];
            if (diff > 0 && b * sampleRate / fftSize < 8000.0) fl += diff;
            prevMag[(size_t) b] = lm;
            if (binPc[(size_t) b] >= 0) chroma[(size_t) binPc[(size_t) b]] += std::sqrt ((double) mag);
        }
        flux.push_back (fl);
    }

    // ---- BPM: автокорреляция огибающей атак
    const double fps = sampleRate / hop;
    const size_t m = flux.size();
    if (m > 64)
    {
        std::vector<double> env (m);
        const int w = (int) (fps * 0.5);
        for (size_t i = 0; i < m; ++i)
        {
            double s = 0; int c = 0;
            for (int k = -w; k <= w; ++k)
            {
                const long j = (long) i + k;
                if (j >= 0 && j < (long) m) { s += flux[(size_t) j]; ++c; }
            }
            env[i] = std::max (0.0, flux[i] - s / c);
        }

        const int minLag = (int) std::floor (fps * 60.0 / 200.0);
        const int maxLag = (int) std::ceil (fps * 60.0 / 55.0);
        std::vector<double> ac ((size_t) maxLag * 4 + 2, 0.0);
        for (size_t lag = 1; lag < ac.size() && lag < m; ++lag)
        {
            double s = 0;
            for (size_t i = lag; i < m; ++i) s += env[i] * env[i - lag];
            ac[lag] = s / (double) (m - lag);
        }

        double best = -1; int bestLag = 0;
        for (int lag = minLag; lag <= maxLag; ++lag)
        {
            const double bpm = 60.0 * fps / lag;
            const double prior = std::exp (-0.5 * std::pow (std::log2 (bpm / 120.0) / 0.9, 2.0));
            double score = ac[(size_t) lag];
            if ((size_t) lag * 2 < ac.size()) score += 0.5 * ac[(size_t) lag * 2];
            if ((size_t) lag * 4 < ac.size()) score += 0.25 * ac[(size_t) lag * 4];
            score *= prior;
            if (score > best) { best = score; bestLag = lag; }
        }

        if (bestLag > 0)
        {
            double lag = bestLag;
            if (bestLag > 1 && (size_t) bestLag + 1 < ac.size())
            {
                const double a = ac[(size_t) bestLag - 1], b = ac[(size_t) bestLag], c = ac[(size_t) bestLag + 1];
                const double den = a - 2 * b + c;
                if (std::abs (den) > 1e-12) lag += juce::jlimit (-0.5, 0.5, 0.5 * (a - c) / den);
            }
            double bpm = 60.0 * fps / lag;
            while (bpm < 70.0) bpm *= 2.0;
            while (bpm > 180.0) bpm /= 2.0;
            // мелкие погрешности округляем к целому, если рядом
            if (std::abs (bpm - std::round (bpm)) < 0.35) bpm = std::round (bpm);
            r.bpm = std::round (bpm * 10.0) / 10.0;
        }
    }

    // ---- Тональность: профили Крумхансла
    static const double majorP[] = { 6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88 };
    static const double minorP[] = { 6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17 };

    auto corr = [&] (const double* prof, int root)
    {
        double mx = 0, my = 0;
        for (int i = 0; i < 12; ++i) { mx += chroma[(size_t) i]; my += prof[i]; }
        mx /= 12; my /= 12;
        double sxy = 0, sxx = 0, syy = 0;
        for (int i = 0; i < 12; ++i)
        {
            const double x = chroma[(size_t) ((i + root) % 12)] - mx, y = prof[i] - my;
            sxy += x * y; sxx += x * x; syy += y * y;
        }
        return (sxx > 0 && syy > 0) ? sxy / std::sqrt (sxx * syy) : 0.0;
    };

    double bestC = -2, second = -2;
    for (int root = 0; root < 12; ++root)
        for (int mode = 0; mode < 2; ++mode)
        {
            const double c = corr (mode ? minorP : majorP, root);
            if (c > bestC) { second = bestC; bestC = c; r.key = root; r.minor = mode == 1; }
            else if (c > second) second = c;
        }
    r.keyConfidence = juce::jlimit (0.0, 1.0, (bestC - second) * 5.0 + bestC * 0.5);
    return r;
}

FitPlan planFit (double srcBpm, double dstBpm, int srcKey, bool srcMinor,
                 int dstKey, bool dstMinor, bool fitTempo, bool fitKey)
{
    FitPlan p;
    if (fitTempo && srcBpm > 0 && dstBpm > 0)
    {
        // учитываем половинный/двойной темп — выбираем наименьшее растяжение
        double best = dstBpm / srcBpm;
        for (double mult : { 0.5, 2.0 })
        {
            const double r = dstBpm * mult / srcBpm;
            if (std::abs (std::log2 (r)) < std::abs (std::log2 (best))) best = r;
        }
        p.tempoRatio = best;
    }
    if (fitKey && srcKey >= 0 && dstKey >= 0)
    {
        // разные лады — приводим к относительному мажору (Am -> C)
        const int s = srcMinor ? (srcKey + 3) % 12 : srcKey;
        const int d = dstMinor ? (dstKey + 3) % 12 : dstKey;
        int diff = ((d - s) % 12 + 12) % 12;
        if (diff > 6) diff -= 12;
        p.semitones = diff;
    }
    return p;
}
}
