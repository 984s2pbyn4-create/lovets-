#pragma once
#include "Tools.h"
#include <vector>

namespace lv
{
// Поиск момента произнесения фразы в роликах YouTube по субтитрам. By il_klmv
struct Word { juce::String norm, text; double start = 0, end = 0; };

struct Hit
{
    juce::String videoId, title, channel, context;
    double start = 0, end = 0;
    bool autoCaptions = true;
    juce::String url() const { return "https://www.youtube.com/watch?v=" + videoId + "&t=" + juce::String ((int) start) + "s"; }
};

juce::String normaliseWord (const juce::String& w);
juce::StringArray tokenise (const juce::String& text);            // нормализованные слова
std::vector<Word> parseJson3 (const juce::String& json);          // формат субтитров YouTube json3
std::vector<Hit> findPhrase (const std::vector<Word>& words, const juce::StringArray& phrase);

struct SearchCallbacks
{
    std::function<void (const juce::String&, float)> status;
    std::function<void (const Hit&)> hit;
};

// Ищет top-N роликов, качает субтитры, возвращает найденные моменты
void runPhraseSearch (const juce::String& phrase, const juce::String& lang, int maxVideos,
                      const ToolPaths& tools, const juce::String& cookies,
                      ProcessRunner& runner, const SearchCallbacks& cb);
}
