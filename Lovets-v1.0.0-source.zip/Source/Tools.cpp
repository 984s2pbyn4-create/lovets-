#include "Tools.h"

namespace lv
{
using namespace juce;

File appDataDir()
{
    auto d = File::getSpecialLocation (File::userApplicationDataDirectory)
#if JUCE_MAC
                 .getChildFile ("Application Support")
#endif
                 .getChildFile ("il_klmv").getChildFile ("Lovets");
    d.createDirectory();
    return d;
}

File toolsDir() { auto d = appDataDir().getChildFile ("bin"); d.createDirectory(); return d; }
File tempDir()  { auto d = appDataDir().getChildFile ("tmp"); d.createDirectory(); return d; }

static String exe (const String& name)
{
#if JUCE_WINDOWS
    return name + ".exe";
#else
    return name;
#endif
}

static File findTool (const String& name)
{
    auto f = toolsDir().getChildFile (exe (name));
    if (f.existsAsFile()) return f;

    StringArray dirs;
    dirs.addTokens (SystemStats::getEnvironmentVariable ("PATH", ""),
#if JUCE_WINDOWS
                    ";",
#else
                    ":",
#endif
                    "");
    const auto home = File::getSpecialLocation (File::userHomeDirectory);
    dirs.add (home.getChildFile (".local/bin").getFullPathName());
    dirs.add (home.getChildFile (".deno/bin").getFullPathName());
#if ! JUCE_WINDOWS
    dirs.addArray ({ "/opt/homebrew/bin", "/usr/local/bin", "/usr/bin", "/bin", "/var/lib/flatpak/exports/bin" });
#endif
    for (auto& d : dirs)
    {
        if (d.isEmpty() || ! File::isAbsolutePath (d)) continue;
        auto c = File (d).getChildFile (exe (name));
        if (c.existsAsFile()) return c;
    }
    return {};
}

ToolPaths locateTools()
{
    ToolPaths t;
    t.ytdlp = findTool ("yt-dlp");
    t.ffmpeg = findTool ("ffmpeg");
    t.deno = findTool ("deno");
    return t;
}

// ---------------------------------------------------------------- загрузка файлов
static bool download (const String& url, const File& dest, const String& label,
                      const ProgressFn& progress, std::atomic<bool>& cancel, String& error)
{
    int status = 0;
    StringPairArray headers;
    auto stream = URL (url).createInputStream (URL::InputStreamOptions (URL::ParameterHandling::inAddress)
                                                   .withConnectionTimeoutMs (20000)
                                                   .withNumRedirectsToFollow (10)
                                                   .withStatusCode (&status)
                                                   .withResponseHeaders (&headers));
    if (stream == nullptr || (status != 0 && status >= 400))
    {
        error = TR ("Не удалось скачать ") + label + " (HTTP " + String (status) + ")";
        return false;
    }
    const auto total = stream->getTotalLength();
    dest.deleteFile();
    FileOutputStream out (dest);
    if (! out.openedOk()) { error = TR ("Нет доступа к ") + dest.getFullPathName(); return false; }

    HeapBlock<char> buf (65536);
    int64 got = 0;
    while (! stream->isExhausted())
    {
        if (cancel) { error = TR ("Отменено"); return false; }
        const int r = stream->read (buf, 65536);
        if (r <= 0) break;
        out.write (buf, (size_t) r);
        got += r;
        progress (TR ("Скачиваю ") + label + ": " + String (got / 1048576.0, 1) + TR (" МБ"),
                  total > 0 ? (float) got / (float) total : -1.0f);
    }
    out.flush();
    if (got < 1024) { error = TR ("Пустой файл: ") + label; return false; }
    return true;
}

static File findInTree (const File& root, const String& fileName)
{
    for (const auto& e : RangedDirectoryIterator (root, true, fileName, File::findFiles))
        return e.getFile();
    return {};
}

static bool extractTo (const File& archive, const File& dir, String& error)
{
    dir.deleteRecursively();
    dir.createDirectory();
    if (archive.getFileName().endsWith (".gz") && ! archive.getFileName().endsWith (".tar.gz"))
    {
        FileInputStream in (archive); // один сжатый бинарник (ffmpeg-static для macOS)
        GZIPDecompressorInputStream gz (&in, false, GZIPDecompressorInputStream::gzipFormat);
        FileOutputStream out (dir.getChildFile (exe ("ffmpeg")));
        if (! in.openedOk() || ! out.openedOk() || out.writeFromInputStream (gz, -1) < 1024)
        { error = TR ("Ошибка распаковки ffmpeg"); return false; }
        return true;
    }
    if (archive.getFileName().endsWith (".zip"))
    {
        ZipFile zip (archive);
        auto res = zip.uncompressTo (dir, true);
        if (res.failed()) { error = res.getErrorMessage(); return false; }
        return true;
    }
    ChildProcess p; // .tar.xz
    if (! p.start (StringArray { "tar", "-xJf", archive.getFullPathName(), "-C", dir.getFullPathName() }))
    { error = TR ("Не найден tar"); return false; }
    p.waitForProcessToFinish (180000);
    if (p.getExitCode() != 0) { error = TR ("Ошибка распаковки: ") + p.readAllProcessOutput(); return false; }
    return true;
}

static void makeExecutable (const File& f)
{
#if ! JUCE_WINDOWS
    f.setExecutePermission (true);
#endif
#if JUCE_MAC
    ChildProcess p; // снимаем карантин, иначе macOS заблокирует запуск
    if (p.start (StringArray { "xattr", "-d", "com.apple.quarantine", f.getFullPathName() }))
        p.waitForProcessToFinish (5000);
#endif
}

bool installTools (const ProgressFn& progress, std::atomic<bool>& cancel, String& error)
{
    const auto bin = toolsDir();
    const auto tmp = tempDir();

#if JUCE_WINDOWS
    const String ytUrl = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe";
    const String ffUrl = "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip";
    const String denoUrl = "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip";
#elif JUCE_MAC
    const String ytUrl = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos";
   #if JUCE_ARM
    const String ffUrl = "https://github.com/eugeneware/ffmpeg-static/releases/latest/download/ffmpeg-darwin-arm64.gz";
   #else
    const String ffUrl = "https://github.com/eugeneware/ffmpeg-static/releases/latest/download/ffmpeg-darwin-x64.gz";
   #endif
   #if JUCE_ARM
    const String denoUrl = "https://github.com/denoland/deno/releases/latest/download/deno-aarch64-apple-darwin.zip";
   #else
    const String denoUrl = "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-apple-darwin.zip";
   #endif
#else
   #if JUCE_ARM
    const String ytUrl = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux_aarch64";
    const String ffUrl = "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-linuxarm64-gpl.tar.xz";
    const String denoUrl = "https://github.com/denoland/deno/releases/latest/download/deno-aarch64-unknown-linux-gnu.zip";
   #else
    const String ytUrl = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux";
    const String ffUrl = "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-linux64-gpl.tar.xz";
    const String denoUrl = "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-unknown-linux-gnu.zip";
   #endif
#endif

    // 1. yt-dlp — всегда обновляем (YouTube часто меняется)
    {
        auto f = bin.getChildFile (exe ("yt-dlp"));
        auto part = bin.getChildFile (exe ("yt-dlp") + ".part");
        if (! download (ytUrl, part, "yt-dlp", progress, cancel, error)) return false;
        f.deleteFile();
        part.moveFileTo (f);
        makeExecutable (f);
    }

    // 2. ffmpeg (+ ffprobe). Ошибка не прерывает установку deno
    String ffError;
    if (! bin.getChildFile (exe ("ffmpeg")).existsAsFile())
    {
        auto arcName = ffUrl.endsWith (".tar.xz") ? "ffmpeg.tar.xz" : (ffUrl.endsWith (".gz") ? "ffmpeg.gz" : "ffmpeg.zip");
        auto arc = tmp.getChildFile (arcName);
        auto ex = tmp.getChildFile ("ffmpeg_x");
        if (download (ffUrl, arc, "ffmpeg", progress, cancel, ffError))
        {
            progress (TR ("Распаковываю ffmpeg…"), -1.0f);
            if (extractTo (arc, ex, ffError))
            {
                for (auto name : { "ffmpeg", "ffprobe" })
                {
                    auto f = findInTree (ex, exe (name));
                    if (f.existsAsFile())
                    {
                        auto dst = bin.getChildFile (exe (name));
                        dst.deleteFile();
                        f.moveFileTo (dst);
                        makeExecutable (dst);
                    }
                }
                if (! bin.getChildFile (exe ("ffmpeg")).existsAsFile()) ffError = TR ("ffmpeg не найден в архиве");
            }
        }
        ex.deleteRecursively();
        arc.deleteFile();
        if (cancel) { error = TR ("Отменено"); return false; }
    }

    // 3. deno — JS-движок, который нужен yt-dlp для YouTube
    if (! bin.getChildFile (exe ("deno")).existsAsFile())
    {
        auto arc = tmp.getChildFile ("deno.zip");
        if (download (denoUrl, arc, "deno", progress, cancel, error))
        {
            auto ex = tmp.getChildFile ("deno_x");
            if (extractTo (arc, ex, error))
            {
                auto f = findInTree (ex, exe ("deno"));
                if (f.existsAsFile())
                {
                    auto dst = bin.getChildFile (exe ("deno"));
                    f.moveFileTo (dst);
                    makeExecutable (dst);
                }
            }
            ex.deleteRecursively();
            arc.deleteFile();
        }
        error.clear(); // deno не критичен
    }

    if (ffError.isNotEmpty()) { error = ffError; return false; }
    progress (TR ("Инструменты установлены"), 1.0f);
    return true;
}

// ---------------------------------------------------------------- процессы
int ProcessRunner::run (const StringArray& args, const std::function<void (const String&)>& onLine, String* fullOutput)
{
    ChildProcess proc;
    if (killed) return -2;
    if (! proc.start (args, ChildProcess::wantStdOut | ChildProcess::wantStdErr))
        return -1;
    {
        std::lock_guard<std::mutex> l (mutex);
        active = &proc;
    }

    MemoryOutputStream all, line;
    char buf[256];
    int emptyAfterExit = 0;
    for (;;)
    {
#if JUCE_WINDOWS
        const int r = proc.readProcessOutput (buf, sizeof (buf));
#else
        const int r = proc.readProcessOutput (buf, 1); // posix fread блокирует до заполнения буфера
#endif
        if (r <= 0)
        {
            if (killed) break;
            if (! proc.isRunning() && ++emptyAfterExit > 3) break;
            Thread::sleep (10);
            continue;
        }
        for (int i = 0; i < r; ++i)
        {
            const char ch = buf[i];
            if (fullOutput != nullptr) all.writeByte (ch);
            if (ch == '\n' || ch == '\r')
            {
                if (line.getDataSize() > 0 && onLine) onLine (line.toUTF8());
                line.reset();
            }
            else line.writeByte (ch);
        }
    }
    if (line.getDataSize() > 0 && onLine) onLine (line.toUTF8());
    proc.waitForProcessToFinish (5000);
    {
        std::lock_guard<std::mutex> l (mutex);
        active = nullptr;
    }
    if (fullOutput != nullptr) *fullOutput = all.toUTF8();
    return killed ? -2 : (int) proc.getExitCode();
}

void ProcessRunner::kill()
{
    killed = true;
    std::lock_guard<std::mutex> l (mutex);
    if (active != nullptr) active->kill();
}

StringArray ytdlpBase (const ToolPaths& t, const String& cookiesFile)
{
    StringArray a { t.ytdlp.getFullPathName(), "--no-warnings", "--encoding", "utf-8", "--newline", "--no-playlist" };
    if (t.ffmpeg.existsAsFile()) a.addArray ({ "--ffmpeg-location", t.ffmpeg.getParentDirectory().getFullPathName() });
    if (t.deno.existsAsFile())   a.addArray ({ "--js-runtimes", "deno:" + t.deno.getFullPathName() });
    if (cookiesFile.isNotEmpty() && File (cookiesFile).existsAsFile()) a.addArray ({ "--cookies", cookiesFile });
    return a;
}

String formatTime (double s, bool withMs)
{
    if (s < 0) s = 0;
    const int h = (int) (s / 3600), m = (int) (s / 60) % 60;
    const double sec = s - h * 3600 - m * 60;
    String r = h > 0 ? String (h) + ":" + String (m).paddedLeft ('0', 2) : String (m);
    r << ":" << (withMs ? String (sec, 1).paddedLeft ('0', 4) : String ((int) sec).paddedLeft ('0', 2));
    return r;
}

double parseTime (const String& text)
{
    auto t = text.trim().replaceCharacter (',', '.');
    if (t.isEmpty()) return -1;
    StringArray parts;
    parts.addTokens (t, ":", "");
    double v = 0;
    for (auto& p : parts)
    {
        if (! p.containsOnly ("0123456789.")) return -1;
        v = v * 60.0 + p.getDoubleValue();
    }
    return v;
}
}
