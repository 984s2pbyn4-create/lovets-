#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include "Tools.h"
#include "Analysis.h"
#include "PhraseSearch.h"

// ЛОВЕЦ (Lovets) — YouTube → WAV, поиск фраз, BPM/тональность. By il_klmv
#define LOVETS_VERSION "1.0.1"
#define LOVETS_AUTHOR  "By il_klmv"

class LovetsProcessor : public juce::AudioProcessor
{
public:
    LovetsProcessor();
    ~LovetsProcessor() override;

    // ---- AudioProcessor
    void prepareToPlay (double sampleRate, int) override { hostRate = sampleRate; }
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Lovets"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return "Default"; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    // ---- настройки (ValueTree сохраняется в проекте DAW)
    juce::ValueTree settings { "LovetsSettings" };
    juce::File outputDir() const;
    juce::String getSetting (const juce::Identifier& id, const juce::var& def) const { return settings.getProperty (id, def).toString(); }

    // ---- задачи (выполняются в фоне)
    void refreshTools();
    juce::String toolsSummary() const;
    bool toolsReady() const { const juce::ScopedLock l (lock); return tools.ready(); }
    void installTools();
    void downloadUrl (const juce::String& url, double startSec, double endSec);
    void downloadHit (const lv::Hit& hit, bool fullVideo);
    void searchPhrase (const juce::String& phrase, const juce::String& lang, int maxVideos);
    void fitClip (double srcBpm, double dstBpm, int srcKey, bool srcMinor, int dstKey, bool dstMinor,
                  bool fitTempo, bool fitKey, int extraSemitones);
    void loadClip (const juce::File& f);   // загрузка + анализ (в фоне)
    void cancel();
    bool isBusy() const { return busy.load(); }

    // ---- состояние для интерфейса (опрос таймером)
    struct Status { juce::String text; float progress = 0; };
    Status getStatus() const { const juce::ScopedLock l (lock); return status; }
    std::vector<lv::Hit> getHits() const { const juce::ScopedLock l (lock); return hits; }
    std::atomic<int> hitsVersion { 0 }, clipVersion { 0 };
    juce::File getClipFile() const { const juce::ScopedLock l (lock); return clipFile; }
    lv::AnalysisResult getAnalysis() const { const juce::ScopedLock l (lock); return analysis; }
    double getClipLength() const { const juce::ScopedLock l (lock); return clipLength; }

    // ---- предпрослушка
    std::atomic<bool> playing { false };
    std::atomic<float> previewGain { 0.8f };
    std::atomic<double> playPos { 0 };
    std::atomic<double> hostBpm { 0 };
    std::atomic<int> clipSamples { 0 };
    double playFraction() const { const int n = clipSamples.load(); return n > 0 ? juce::jlimit (0.0, 1.0, playPos.load() / n) : 0.0; }
    juce::AudioFormatManager formats;

private:
    void setStatus (const juce::String& t, float p);
    void runJob (const juce::String& name, std::function<void()> job);
    juce::File runDownload (const juce::StringArray& extraArgs, const juce::String& url, const juce::String& suffix);
    void loadClipNow (const juce::File& f);

    juce::CriticalSection lock;
    Status status;
    std::vector<lv::Hit> hits;
    lv::ToolPaths tools;
    lv::ProcessRunner runner;
    std::atomic<bool> cancelFlag { false }, busy { false };
    juce::ThreadPool pool { 1 };

    juce::SpinLock audioLock;
    juce::AudioBuffer<float> clip;
    double clipRate = 44100, hostRate = 44100, clipLength = 0;
    juce::File clipFile;
    lv::AnalysisResult analysis;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LovetsProcessor)
};
