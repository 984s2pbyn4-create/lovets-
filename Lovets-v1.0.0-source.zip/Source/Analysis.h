#pragma once
#include <juce_audio_basics/juce_audio_basics.h>

namespace lv
{
// Анализ темпа и тональности. By il_klmv
struct AnalysisResult
{
    double bpm = 0.0;
    int key = -1;          // 0 = C ... 11 = B
    bool minor = false;
    double keyConfidence = 0.0;
    bool valid() const { return bpm > 0.0 && key >= 0; }
};

juce::String keyName (int key, bool minor);          // "C#m", "F"
juce::String camelot (int key, bool minor);          // "8A"
AnalysisResult analyse (const juce::AudioBuffer<float>& buffer, double sampleRate);

// Подгонка: во сколько раз ускорить (tempoRatio) и на сколько полутонов сдвинуть
struct FitPlan { double tempoRatio = 1.0; int semitones = 0; };
FitPlan planFit (double srcBpm, double dstBpm, int srcKey, bool srcMinor,
                 int dstKey, bool dstMinor, bool fitTempo, bool fitKey);
}
