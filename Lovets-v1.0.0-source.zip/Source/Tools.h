#pragma once
#include <juce_core/juce_core.h>
#include <atomic>
#include <functional>
#include <mutex>

// Кириллица в литералах: строки в UTF-8
#define TR(s) juce::String (juce::CharPointer_UTF8 (s))

namespace lv
{
// Внешние инструменты: yt-dlp (загрузка), ffmpeg (конвертация), deno (JS для YouTube). By il_klmv
struct ToolPaths
{
    juce::File ytdlp, ffmpeg, deno;
    bool ready() const { return ytdlp.existsAsFile() && ffmpeg.existsAsFile(); }
};

juce::File appDataDir();
juce::File toolsDir();
juce::File tempDir();
ToolPaths locateTools();

using ProgressFn = std::function<void (const juce::String& status, float progress)>;
bool installTools (const ProgressFn& progress, std::atomic<bool>& cancel, juce::String& error);

// Запуск внешнего процесса с построчным выводом и возможностью отмены
class ProcessRunner
{
public:
    int run (const juce::StringArray& args,
             const std::function<void (const juce::String& line)>& onLine,
             juce::String* fullOutput = nullptr);
    void kill();
    bool wasKilled() const { return killed.load(); }
    void resetKill() { killed = false; }

private:
    std::mutex mutex;
    juce::ChildProcess* active = nullptr;
    std::atomic<bool> killed { false };
};

struct DownloadOptions
{
    juce::String cookiesFile;
    int sampleRate = 48000;
    int bitDepth = 24;
};

// Общие аргументы yt-dlp (пути к ffmpeg/deno, кодировка, cookies)
juce::StringArray ytdlpBase (const ToolPaths& t, const juce::String& cookiesFile);
juce::String formatTime (double seconds, bool withMs = false);
double parseTime (const juce::String& text); // "1:23.5" / "83.5" -> сек; -1 при ошибке
}
