#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "PluginProcessor.h"

class LovetsEditor;

// Тёмная тема «ЛОВЕЦ»
struct LovetsLook : juce::LookAndFeel_V4
{
    LovetsLook();
    static const juce::Colour bg, panel, accent, text, dim;
};

// Область «перетащи в DAW» + волна
class ClipView : public juce::Component, private juce::ChangeListener
{
public:
    explicit ClipView (LovetsProcessor&);
    ~ClipView() override;
    void setFile (const juce::File&);
    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
private:
    void changeListenerCallback (juce::ChangeBroadcaster*) override { repaint(); }
    LovetsProcessor& proc;
    juce::AudioThumbnailCache cache { 4 };
    juce::AudioThumbnail thumb;
    juce::File file;
    bool dragStarted = false;
};

// Файлы, перетащенные в плагин из файлового менеджера
class LovetsEditor : public juce::AudioProcessorEditor,
                     public juce::FileDragAndDropTarget,
                     public juce::DragAndDropContainer,
                     private juce::Timer,
                     private juce::ListBoxModel
{
public:
    explicit LovetsEditor (LovetsProcessor&);
    ~LovetsEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;

    bool isInterestedInFileDrag (const juce::StringArray&) override { return true; }
    void filesDropped (const juce::StringArray& files, int, int) override;

private:
    void timerCallback() override;
    int getNumRows() override { return (int) hits.size(); }
    void paintListBoxItem (int row, juce::Graphics&, int w, int h, bool selected) override;
    void listBoxItemDoubleClicked (int row, const juce::MouseEvent&) override;

    void layoutDownload (juce::Rectangle<int>);
    void layoutSearch (juce::Rectangle<int>);
    void layoutFit (juce::Rectangle<int>);
    void layoutSettings (juce::Rectangle<int>);
    void showTab (int);
    void updateAnalysisUi();
    void fillKeyBox (juce::ComboBox&, bool withAuto);
    const lv::Hit* selectedHit() const;

    LovetsProcessor& proc;
    LovetsLook look;
    int currentTab = 0;
    juce::OwnedArray<juce::TextButton> tabButtons;

    // Скачать
    juce::Label urlLabel, rangeLabel, dlHint;
    juce::TextEditor urlEdit, startEdit, endEdit;
    juce::TextButton downloadBtn { TR ("Скачать WAV") }, pasteBtn { TR ("Вставить") };

    // Поиск
    juce::TextEditor phraseEdit;
    juce::ComboBox langBox, countBox;
    juce::TextButton searchBtn { TR ("Найти") }, hitFragBtn { TR ("Скачать момент (WAV)") }, hitFullBtn { TR ("Весь ролик") },
                     hitOpenBtn { TR ("Открыть в браузере") };
    juce::Slider padBefore, padAfter;
    juce::Label padBeforeLbl, padAfterLbl, searchHint;
    juce::ListBox hitList { "hits", this };
    std::vector<lv::Hit> hits;
    int lastHitsVersion = -1;

    // BPM и тональность
    juce::Label srcTitle, dstTitle, srcBpmLbl, srcKeyLbl, dstBpmLbl, dstKeyLbl, hostLbl, semisLbl, fitInfo;
    juce::TextEditor srcBpmEdit, dstBpmEdit;
    juce::ComboBox srcKeyBox, dstKeyBox;
    juce::ToggleButton useHostBpm { TR ("Брать темп из DAW") }, fitTempoTgl { TR ("Подогнать темп") }, fitKeyTgl { TR ("Подогнать тональность") };
    juce::Slider semisSlider;
    juce::TextButton halfBtn { TR ("÷2") }, doubleBtn { TR ("×2") }, reanalyseBtn { TR ("Анализировать заново") },
                     fitBtn { TR ("Создать подогнанный WAV") };

    // Настройки
    juce::Label toolsLbl, outLbl, rateLbl, bitsLbl, cookiesLbl, aboutLbl;
    juce::TextButton installBtn { TR ("Установить / обновить инструменты") }, recheckBtn { TR ("Проверить снова") },
                     outBtn { TR ("Папка для WAV…") }, cookiesBtn { TR ("Файл cookies…") }, cookiesClearBtn { TR ("Сбросить") };
    juce::ComboBox rateBox, bitsBox;
    std::unique_ptr<juce::FileChooser> chooser;

    // Низ: клип и статус
    ClipView clipView;
    juce::Label clipInfo, statusLbl;
    juce::TextButton playBtn { TR ("▶ Слушать") }, revealBtn { TR ("Показать в папке") }, cancelBtn { TR ("Стоп") };
    juce::Slider gainSlider;
    double progressValue = 0;
    juce::ProgressBar progress { progressValue };
    int lastClipVersion = -1;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LovetsEditor)
};
